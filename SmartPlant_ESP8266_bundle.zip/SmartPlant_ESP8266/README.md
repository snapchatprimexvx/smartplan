# Smart Plant Monitor — ESP8266 D1 mini / NodeMCU

## Important: hosting vs. flashing
This project is ESP8266 firmware, not a website that can run directly on Vercel.
The ESP8266 itself creates a Wi-Fi network and serves the dashboard from the board.
You do **not** need Vercel to use the dashboard locally.

## Files
- `SmartPlant_ESP8266.ino` — firmware to upload to the ESP8266.

## Arduino IDE setup
1. Install Arduino IDE.
2. Add ESP8266 board support in Boards Manager (search for `esp8266` by ESP8266 Community).
3. Install the `LiquidCrystal_I2C` library from Library Manager.
4. Select your ESP8266 board (for example, NodeMCU 1.0 or LOLIN(WEMOS) D1 mini) and the correct COM/USB port.
5. Open `SmartPlant_ESP8266.ino`, then click Verify and Upload.

## Connect to the dashboard
1. Power the ESP8266.
2. On your phone, join Wi-Fi `SmartPlant_D1`.
3. Password: `Plant1234`.
4. Open `http://192.168.4.1` in your browser.
5. The phone must stay connected to the ESP8266 Wi-Fi while using the dashboard.

## Calibration and wiring checks
- `DRY_VALUE` and `WET_VALUE` are example values. Read the sensor's raw value in Serial Monitor and calibrate for your sensor.
- Confirm the relay module's trigger polarity. The default code assumes active-LOW relay.
- The ESP8266 A0 input voltage limit depends on the board. Do not exceed the board's specified A0 voltage.
- Do not power a water pump directly from an ESP8266 pin. Use a suitable relay/driver and separate pump supply, with safe wiring.
- Test with the pump disconnected first. Verify that the relay is OFF at startup and that AUTO/MANUAL behavior is correct.
- Change the Wi-Fi password before using this beyond a quick local demo.

## If you need a public Vercel website
A Vercel-hosted HTTPS page cannot reliably control this local HTTP-only ESP8266 access point directly because the board is only reachable on its own Wi-Fi and browsers restrict HTTPS-to-HTTP requests. Remote access needs a cloud connection (for example, an MQTT/cloud backend) and authentication. This ZIP is for the local ESP8266 dashboard.
