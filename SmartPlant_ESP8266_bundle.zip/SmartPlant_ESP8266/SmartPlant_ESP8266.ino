#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// -------- Wi-Fi Access Point --------
const char* ssid = "SmartPlant_D1";
const char* password = "Plant1234";

ESP8266WebServer server(80);

// -------- Pin Configuration --------
#define SOIL_PIN A0
#define RELAY_PIN D5
#define BUZZER_PIN D6
#define LED_PIN D7

// -------- LCD Configuration --------
LiquidCrystal_I2C lcd(0x27, 16, 2);

// -------- Sensor Calibration --------
int DRY_VALUE = 800;
int WET_VALUE = 350;

// -------- Moisture Thresholds --------
const int PUMP_ON_LEVEL = 35;
const int PUMP_OFF_LEVEL = 50;

// Relay module active LOW. Swap these if your relay is active HIGH.
const int RELAY_ON = LOW;
const int RELAY_OFF = HIGH;

// -------- System Variables --------
int rawValue = 0;
int moisture = 0;
bool pumpOn = false;
bool autoMode = true;
unsigned long lastLCDUpdate = 0;
bool lcdPage = false;

// -------- Read Soil Moisture --------
void readSoil() {
  rawValue = analogRead(SOIL_PIN);
  moisture = map(rawValue, DRY_VALUE, WET_VALUE, 0, 100);
  moisture = constrain(moisture, 0, 100);
}

// -------- Pump Control --------
void setPump(bool state) {
  pumpOn = state;
  digitalWrite(RELAY_PIN, pumpOn ? RELAY_ON : RELAY_OFF);
}

// -------- Automatic Irrigation --------
void automaticControl() {
  if (!autoMode) return;

  if (moisture < PUMP_ON_LEVEL) {
    setPump(true);
  } else if (moisture >= PUMP_OFF_LEVEL) {
    setPump(false);
  }
}

// -------- Buzzer and LED --------
void updateIndicators() {
  if (moisture < PUMP_ON_LEVEL) {
    digitalWrite(BUZZER_PIN, HIGH);
    digitalWrite(LED_PIN, HIGH);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
  }
}

// -------- LCD Display --------
void updateLCD() {
  if (millis() - lastLCDUpdate < 2000) return;

  lastLCDUpdate = millis();
  lcdPage = !lcdPage;
  lcd.clear();

  if (!lcdPage) {
    lcd.setCursor(0, 0);
    lcd.print("Soil: ");
    lcd.print(moisture);
    lcd.print("%");
    lcd.setCursor(0, 1);

    if (moisture < PUMP_ON_LEVEL) {
      lcd.print("Soil is DRY!");
    } else if (moisture < PUMP_OFF_LEVEL) {
      lcd.print("Soil is NORMAL");
    } else {
      lcd.print("Soil is WET");
    }
  } else {
    lcd.setCursor(0, 0);
    lcd.print("Pump: ");
    lcd.print(pumpOn ? "ON" : "OFF");
    lcd.setCursor(0, 1);
    lcd.print("Mode: ");
    lcd.print(autoMode ? "AUTO" : "MANUAL");
  }
}

// -------- Web Dashboard --------
String makePage() {
  String page = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<title>Smart Plant Monitor</title>
<style>
* { box-sizing: border-box; }
body {
  font-family: Arial, sans-serif;
  text-align: center;
  background: #eef7ee;
  margin: 0;
  padding: 20px;
  color: #18351e;
}
.card {
  background: white;
  max-width: 440px;
  margin: 12px auto;
  padding: 22px;
  border-radius: 14px;
  box-shadow: 0 2px 10px #bbb;
}
h2 { color: #23823b; margin-top: 0; }
.value { font-size: 42px; font-weight: bold; }
button {
  padding: 12px 18px;
  margin: 6px;
  border: 0;
  border-radius: 8px;
  color: white;
  background: #23823b;
  font-size: 16px;
  cursor: pointer;
}
.off { background: #b83232; }
.info { margin: 12px; }
small { color: #526455; }
</style>
</head>
<body>
<div class="card">
<h2>Smart Plant Monitor</h2>
<div class="info">Soil Moisture</div>
<div class="value" id="moisture">--%</div>
<div class="info">Raw Sensor: <span id="raw">--</span></div>
<div class="info">Soil Status: <b id="soil">--</b></div>
<div class="info">Pump: <b id="pump">--</b></div>
<div class="info">Mode: <b id="mode">--</b></div>
<hr>
<h3>Operating Mode</h3>
<button onclick="setMode('auto')">AUTO</button>
<button onclick="setMode('manual')">MANUAL</button>
<h3>Manual Pump Control</h3>
<button onclick="setPump('on')">Pump ON</button>
<button class="off" onclick="setPump('off')">Pump OFF</button>
<p id="message">Connecting...</p>
<small>Connect your phone to the SmartPlant_D1 Wi-Fi network first.</small>
</div>
<script>
async function refreshData() {
  try {
    const response = await fetch('/api');
    if (!response.ok) throw new Error('API request failed');
    const d = await response.json();
    document.getElementById('moisture').textContent = d.moisture + '%';
    document.getElementById('raw').textContent = d.raw;
    document.getElementById('soil').textContent = d.soil;
    document.getElementById('pump').textContent = d.pump ? 'ON' : 'OFF';
    document.getElementById('mode').textContent = d.auto ? 'AUTO' : 'MANUAL';
    document.getElementById('message').textContent = 'Dashboard connected';
  } catch(e) {
    document.getElementById('message').textContent = 'Connection lost. Retrying...';
  }
}
async function setMode(mode) {
  try {
    const r = await fetch('/mode?set=' + encodeURIComponent(mode));
    document.getElementById('message').textContent =
      r.ok ? 'Mode updated' : 'Mode command failed';
    await refreshData();
  } catch(e) {
    document.getElementById('message').textContent = 'Connection error';
  }
}
async function setPump(state) {
  try {
    const r = await fetch('/pump?state=' + encodeURIComponent(state));
    const message = await r.text();
    document.getElementById('message').textContent = r.ok ? message :
      (r.status === 409 ? 'Switch to MANUAL mode first' : 'Pump command failed');
    await refreshData();
  } catch(e) {
    document.getElementById('message').textContent = 'Connection error';
  }
}
refreshData();
setInterval(refreshData, 2000);
</script>
</body>
</html>
)rawliteral";
  return page;
}

// -------- Web Server Handlers --------
void handleRoot() {
  server.send(200, "text/html; charset=utf-8", makePage());
}

void handleAPI() {
  String soilStatus;
  if (moisture < PUMP_ON_LEVEL) {
    soilStatus = "DRY";
  } else if (moisture < PUMP_OFF_LEVEL) {
    soilStatus = "NORMAL";
  } else {
    soilStatus = "WET";
  }

  String json = "{";
  json += "\"moisture\":" + String(moisture) + ",";
  json += "\"raw\":" + String(rawValue) + ",";
  json += "\"pump\":" + String(pumpOn ? "true" : "false") + ",";
  json += "\"auto\":" + String(autoMode ? "true" : "false") + ",";
  json += "\"soil\":\"" + soilStatus + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleMode() {
  if (!server.hasArg("set")) {
    server.send(400, "text/plain", "Missing mode");
    return;
  }

  String mode = server.arg("set");
  if (mode == "auto") {
    autoMode = true;
    automaticControl();
    server.send(200, "text/plain", "AUTO mode enabled");
  } else if (mode == "manual") {
    autoMode = false;
    server.send(200, "text/plain", "MANUAL mode enabled");
  } else {
    server.send(400, "text/plain", "Invalid mode");
  }
}

void handlePump() {
  if (!server.hasArg("state")) {
    server.send(400, "text/plain", "Missing state");
    return;
  }
  if (autoMode) {
    server.send(409, "text/plain", "Switch to MANUAL mode first");
    return;
  }

  String state = server.arg("state");
  if (state == "on") {
    setPump(true);
    server.send(200, "text/plain", "Pump ON");
  } else if (state == "off") {
    setPump(false);
    server.send(200, "text/plain", "Pump OFF");
  } else {
    server.send(400, "text/plain", "Invalid state");
  }
}

// -------- Setup --------
void setup() {
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  // Keep pump off during startup.
  digitalWrite(RELAY_PIN, RELAY_OFF);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(D2, D1);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Smart Plant");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");

  readSoil();

  WiFi.mode(WIFI_AP);
  bool apStarted = WiFi.softAP(ssid, password);
  if (apStarted) {
    Serial.println();
    Serial.println("Smart Plant System Started");
    Serial.print("Wi-Fi Name: ");
    Serial.println(ssid);
    Serial.print("Dashboard: http://");
    Serial.println(WiFi.softAPIP());
  } else {
    Serial.println("ERROR: Wi-Fi access point failed to start");
  }

  server.on("/", handleRoot);
  server.on("/api", handleAPI);
  server.on("/mode", handleMode);
  server.on("/pump", handlePump);
  server.begin();
}

// -------- Main Loop --------
void loop() {
  server.handleClient();
  readSoil();
  automaticControl();
  updateIndicators();
  updateLCD();

  static unsigned long lastSerialUpdate = 0;
  if (millis() - lastSerialUpdate >= 1000) {
    lastSerialUpdate = millis();
    Serial.print("Raw: ");
    Serial.print(rawValue);
    Serial.print(" | Moisture: ");
    Serial.print(moisture);
    Serial.print("% | Pump: ");
    Serial.print(pumpOn ? "ON" : "OFF");
    Serial.print(" | Mode: ");
    Serial.println(autoMode ? "AUTO" : "MANUAL");
  }
  delay(20);
}
